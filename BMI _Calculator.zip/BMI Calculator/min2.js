 

let forms=document.querySelector('form');

forms.addEventListener('submit', function(e){

    //to prevent the default url of the form 
    e.preventDefault();

    let height= parseInt(document.getElementById('height').value);
    let weight= parseInt(document.getElementById('weight').value);
    let result =document.querySelector('#result');
    let results=document.querySelector('#results');
   
    if(height===''|| height<=0||isNaN(height)||weight===''||weight<=0||isNaN(weight)){
        result.innerHTML="please valid data";
    }else{
        //to fixed used for the rounding of near 2 places 
        const bmi=(weight/((height*height)/10000).toFixed(2));
        result.innerHTML=`<span>${bmi}</span>`;
        if(bmi<18.6){
            results.innerHTML=`Under Weight`;
        }
        else if(bmi>=18.6 && bmi<24.9){
            results.innerHTML=`Normal range`;
        }else{
            results.innerHTML=`overweight`;
        }
    }
    
    
})