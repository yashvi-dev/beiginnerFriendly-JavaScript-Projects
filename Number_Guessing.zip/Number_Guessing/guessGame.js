let randNum=[Math.floor(parseInt(Math.random()*100+1))];

console.log(randNum);

let btn=document.querySelector("button");
let userinp=document.getElementById("text");
let lowhi= document.querySelector(".lowhi");
let prevguess=document.querySelector(".pguess");
let remguess=document.querySelector(".lastresult");
let startover=document.querySelector(".result");

let para= document.createElement('p');

let prev=[];



//for tracking the number of attemp
let numGuess=1;

//to allow user to play game 
let playGame=true;

if(playGame){
    btn.addEventListener('click',function(){
        let guess=parseInt(userinp.value)
        console.log(guess)
        validate(guess);
    })
}
//will be used several times at backend to validate it user enterd correct details or not 
//to see if user enterd a -ve num or decimal num or alphbet 
function validate(guess){

if(isNaN(guess)){
    alert('Please enter a valid number');
}else if(guess<1){
    alert('Please enter a valid number');
}
else if(guess>100){
    alert('Please enter a valid number');
}else{
    prev.push(guess)
    if(numGuess===11){
        displayguess(guess)
        displaymsg(`GAME OVER .<br> Random number was ${randNum}`);
        endgame()
    }else{
        displayguess(guess)
        checkguess(guess)
    }
}

}

//to validate the gussed value is high or low or equal...
function checkguess(guess){
    
    const proximityrange=5;

    //not working??
    if (parseInt(guess) === randNum){
        displaymsg('You guessed it right');
        
    }else if(Math.abs(guess-randNum)<= proximityrange){
        displaymsg('You are close!')
    }
    else if(guess<randNum){
        displaymsg('Number is TOO Low ')
    }else if(guess>randNum){
        displaymsg('Number is TOO High')
    }
}

//to clean the values enterd by the user if it is wrong and update the rem and prev guess
function displayguess(guess) {
    userinp.value=''; //sort of cleanup for guess number is wrong
    prevguess.innerHTML+=`${guess},  `;
    numGuess++ ;  
    remguess.innerHTML=`${11-numGuess}`;

}

//displays the message 
function displaymsg(message){
    lowhi.innerHTML =`<h2>${message}</h2>`
}

function endgame() {
    userinp.value='';
    userinp.setAttribute('disabled ','')
    para.classList.add('button')
    para.innerHTML='<h2 id="newGame> Start new Game</h2>';
    startover.appendChild(para);
    playGame=false;
    newGame();
}

function newGame(){
//    let newbtn= document.querySelector("#newGame");
let newbtn = document.getElementById("newGame");
   newbtn.addEventListener('click',function(){
        randNum=[Math.floor(parseInt(Math.random()*100+1))];
        prevguess=[];
        numGuess=1;
        guess.innerHTML='';
        remguess.innerHTML= `${11-numGuess}`;
        userinp.removeAttribute('disable');
        startover.removeChild(p);

        playGame=true;
        
   });

}

