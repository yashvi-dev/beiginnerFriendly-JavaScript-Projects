let btn=document.querySelector(".out-btn");
let password=document.getElementById("password");

const length=12;

const upperCase="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowerCase="abcdefghijklmnopqrstuvwxyz";
const num="123456789";
const symbol="{}()[]#:;^,.?_`~''@$%/\=+-*/";

const allchar=upperCase+lowerCase+  num+  symbol;

 function createpassword(){
    let pass="";
    pass+=upperCase[Math.floor(Math.random()*upperCase.length)];
    pass+=lowerCase[Math.floor(Math.random()*lowerCase.length)];
    pass+=num[Math.floor(Math.random()*num.length)];
    pass+=symbol[Math.floor(Math.random()*symbol.length)];

    while(length>pass.length){
        pass+=allchar[Math.floor(Math.random()*allchar.length)];
    }
    password.value=pass;
}
btn.addEventListener('click',createpassword);