let gameseq=[];
let userseq=[];

let btns=["yellow","red","blue","green"];

let started= false;
//tells ki kya game start hu hai ya nahi
 let level=0; //game has not staretd yet 

 let h2=document.querySelector("h2");
//if any key presses we want we can detect that
//we can put an event listener on the document 

document.addEventListener("keypress",function(){
    // console.log("game started"); this creates ki kitni bhi bar start ho sakta  hai
    if(started==false){
        //will start only once 
        console.log("game started");
        started=true;

        levelup();
    } 
});

function btnFlash(btn){
    btn.classList.add("flash");
    //we will ad the classs but we will remove it after some time  using timeout 
    setTimeout(function() {
        btn.classList.remove("flash")
    }, 250);
}


function gameFlash(btn){
    btn.classList.add("flash");
    
    setTimeout(function() {
        btn.classList.remove("flash")
    }, 250);
}

function userFlash(btn){
    btn.classList.add("userflash");
 setTimeout(function() {
        btn.classList.remove("userflash")
    }, 250);
}

//abhi jo level chal rah hai usse uppar ek level pr jana hai
function levelup(){
    //1.level update 2.flash 3.level ki text value badalni hai 
    level++;
    h2.innerText=`Level ${level}`;
   //btn flash-when user presses btn and in start also we will use fuc

   //random btn choose 
   let randomIndx=Math.floor(Math.random()*4);
   let randColor= btns[randomIndx];
   let randombtn=document.querySelector(`.${randColor}`);
//    console.log(randomIndx);
//    console.log(randColor);
//    console.log(randombtn);

    gameseq.push(randColor);
    console.log(gameseq);
   gameFlash(randombtn);

}

function checkAns(idx){
    // console.log("current level :",level);

    let idx=level-1;
    if(userseq[idx]===gameseq[idx]){
        // console.log("same value");
        if(userseq.length==gameseq.length){
            setTimeout(levelup,1000);
        }
    }else{
        h2.innerText=`Game Over! press any key to start.`
    }
}

function btnPress(){
    console.log(this);
    let btn=this;
    userFlash(btn);

    userColor = btn.getAttribute("id");
    // console.log(userColor);

    userseq.push(userColor);

    checkAns(userseq.length-1);
}

let allbtn=document.querySelectorAll(".btn");
for(btn of allbtn){
    btn.addEventListener("click",btnPress);
}